/**
 * Classes for accepting/receiving transport orders from somewhere else.
 */
package org.opentcs.kernel.xmlhost.orders;
