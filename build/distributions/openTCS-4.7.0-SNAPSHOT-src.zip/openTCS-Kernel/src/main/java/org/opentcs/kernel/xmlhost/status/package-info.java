/**
 * Implementation of an XML based status channel.
 */
package org.opentcs.kernel.xmlhost.status;
