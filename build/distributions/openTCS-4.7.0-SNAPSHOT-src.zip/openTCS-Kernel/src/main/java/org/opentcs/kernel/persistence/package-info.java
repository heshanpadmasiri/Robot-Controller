/**
 * Classes for persisting and materializing openTCS data.
 */
package org.opentcs.kernel.persistence;
