/**
 * The openTCS kernel, its interface for client applications and closely related
 * functionality.
 */
package org.opentcs.kernel;
