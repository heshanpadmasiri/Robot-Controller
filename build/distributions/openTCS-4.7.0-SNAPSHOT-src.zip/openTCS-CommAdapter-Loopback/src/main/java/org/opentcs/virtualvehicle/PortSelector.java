package org.opentcs.virtualvehicle;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class PortSelector extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JList list1;

    public PortSelector() {

        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);
        DefaultListModel<String> listModel = new DefaultListModel<>();
        List<String> portNames = SerialCommunicationFactory.getAvailableSerialPortNames();
        for (String port:portNames){
            listModel.addElement(port);
        }
        list1.setModel(listModel);
        buttonOK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onOK();
            }
        });
    }

    private void onOK() {
        // add your code here
        dispose();
    }

    
}
