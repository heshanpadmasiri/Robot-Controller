/*
 * Copyright (c) The openTCS Authors.
 *
 * This program is free software and subject to the MIT license. (For details,
 * see the licensing information (LICENSE.txt) you should have received with
 * this copy of the software.)
 */
package org.opentcs.virtualvehicle;

import org.opentcs.data.model.Vehicle;
import gnu.io.*;

import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

public class SerialCommunicationFactory {
    private static final SerialCommunication SERIAL_COMMUNICATION = new SerialCommunication();
    private static Byte vehicleId = 0;
    private static final String portId = "COM6";    
    
    public SerialCommunicationFactory(LoopbackCommunicationAdapter CommunicationAdapter){
        PortSelector dialog = new PortSelector();
        dialog.pack();
        dialog.setVisible(true);
        synchronized(SERIAL_COMMUNICATION){
          SerialCommunication.connectToCommunicationAdapter(vehicleId, CommunicationAdapter); 
        }
        try{
          //Change the com port when needed
          SERIAL_COMMUNICATION.connect(portId);
        } catch (Exception e){
          System.out.println("Error Unnable to connect on the port " + portId);
          e.printStackTrace();
        }
    }

  public  SerialCommunication getSerialCommunication() {

        return SERIAL_COMMUNICATION;
  }

  private static HashSet<CommPortIdentifier> getAvailableSerialPorts() {
      HashSet<CommPortIdentifier> h = new HashSet<CommPortIdentifier>();
      Enumeration thePorts = CommPortIdentifier.getPortIdentifiers();
      while (thePorts.hasMoreElements()) {
            CommPortIdentifier com = (CommPortIdentifier) thePorts.nextElement();
            switch (com.getPortType()) {
                case CommPortIdentifier.PORT_SERIAL:
                    try {
                        CommPort thePort = com.open("CommUtil", 50);
                        thePort.close();
                        h.add(com);
                    } catch (PortInUseException e) {
                        System.out.println("Port, "  + com.getName() + ", is in use.");
                    } catch (Exception e) {
                        System.err.println("Failed to open port " +  com.getName());
                        e.printStackTrace();
                    }
            }
      }
      return h;
  }

  public static List<String> getAvailableSerialPortNames(){
        HashSet<CommPortIdentifier> portIdentifiers = getAvailableSerialPorts();
        return portIdentifiers.stream().map(CommPortIdentifier::getName).collect(Collectors.toList());
  }
    
}
