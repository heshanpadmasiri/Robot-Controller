/**
 * Supportive classes for graphical frontends.
 */
package org.opentcs.util.gui;
