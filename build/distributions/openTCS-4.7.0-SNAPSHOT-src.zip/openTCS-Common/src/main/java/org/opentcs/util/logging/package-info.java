/**
 * Utility classes extending basic logging features.
 */
package org.opentcs.util.logging;
