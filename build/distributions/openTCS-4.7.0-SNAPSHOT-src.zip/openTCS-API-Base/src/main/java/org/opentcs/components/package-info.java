/**
 * Interfaces and base classes for exchangeable components of openTCS applications.
 */
package org.opentcs.components;
