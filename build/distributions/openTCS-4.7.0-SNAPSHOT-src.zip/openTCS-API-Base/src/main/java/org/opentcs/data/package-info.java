/**
 * Basic openTCS data structures.
 */
package org.opentcs.data;
