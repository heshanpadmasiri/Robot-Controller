/**
 * Interfaces and classes for transparently providing an openTCS kernel's
 * functionality via RMI.
 */
package org.opentcs.access.rmi;
