/**
 * Interfaces and classes for accessing the kernel from outside, for instance
 * from a remote client or a communication adapter.
 */
package org.opentcs.access;
