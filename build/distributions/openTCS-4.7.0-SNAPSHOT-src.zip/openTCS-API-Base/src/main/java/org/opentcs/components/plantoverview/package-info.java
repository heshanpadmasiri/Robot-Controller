/**
 * Interfaces for pluggable panels, themes and other components for a plant overview application.
 */
package org.opentcs.components.plantoverview;
