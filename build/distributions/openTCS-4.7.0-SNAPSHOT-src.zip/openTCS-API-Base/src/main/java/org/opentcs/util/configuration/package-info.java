/**
 * Classes for loading and storing key/value pairs of configuration data.
 */
package org.opentcs.util.configuration;
