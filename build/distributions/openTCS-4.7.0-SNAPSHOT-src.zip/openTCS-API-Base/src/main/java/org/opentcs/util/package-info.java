/**
 * A collection of classes providing miscellaneous functions that are used
 * throughout openTCS.
 */
package org.opentcs.util;
