/**
 * Interfaces and classes for event handling.
 */
package org.opentcs.util.eventsystem;
