/**
 * Classes for user/kernel client management.
 */
package org.opentcs.data.user;
