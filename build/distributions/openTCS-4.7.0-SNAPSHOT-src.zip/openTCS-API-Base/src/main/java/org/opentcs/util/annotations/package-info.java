/**
 * Useful annotations.
 */
package org.opentcs.util.annotations;
